$(document).ready(function () {
    $('.start_date').datepicker();
    $('.time_start').timepicker();
    $('.time_end').timepicker();
    $(".dropdown-trigger").dropdown();
    $(".dropdown-trigger-main").dropdown();
    $('.sidenav').sidenav();
    $('.modal').modal();
    $('.slider').slider();



    M.updateTextFields();
});